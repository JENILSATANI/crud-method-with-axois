import React, { useState, useEffect, useRef } from 'react';
import { useHistory, useParams } from "react-router-dom";
import axios from 'axios';

const Pp = () => {
    // const { id } = localStorage.getItem('_id');
    let history = useHistory();
    const fileInputRef = useRef();

    const [Fristname, setFristname] = useState('')
    const [email, setEmail] = useState('')
    const [password, setPassword] = useState('')
    const [photo, setphoto] = useState('')
    const [file, setfile] = useState()
    //  this is err validation add in From
    const [FirstnameErr, setFristnameErr] = useState({});
    const [emailErr, setemailErr] = useState({})


    const [allEntry, setAllEntry] = useState([])
    const submitForm = (e) => {
        e.preventDefault();
        const isValid = formValidation()

        const newEntry = { Fristname, email, password, photo, file}

        if (isValid) {
            setAllEntry([...allEntry, newEntry])
            setFristname('');
            setEmail('')
            setPassword('')
            // setfile([])
        }
    }


    const formValidation = () => {
        const FirstnameErr = {};
        const emailErr = {};
        let isValid = true;

        if (Fristname.trim().length < 5) {
            FirstnameErr.Firstname = "Frist Name is Not Valid"
            isValid = false;
        }
        if (!email.includes("@")) {
            // emailValid = value.match(/^([\w.%+-]+)@([\w-]+\.)+([\w]{2,})$/i);
            emailErr.email = "@ must have in email";
            isValid = false;
        }
        setFristnameErr(FirstnameErr)
        setemailErr(emailErr)
        return isValid

    }
    useEffect(() => {
        if(fileInputRef) fileInputRef.current.value= null
        getuser()
    }, [file])

    const getuser = () => {
        let user_id = localStorage.getItem('_id');
        console.log("id----------", user_id);
        if (user_id === undefined || user_id === null) {
            return;
        } else {
            axios.get(`http://localhost:9600/api/get/${user_id}`).then((result) => {
                console.log("result.data", result.data)
                if (result.data.success === true) {
                    setFristname(result.data.data.name)
                    setEmail(result.data.data.gmail)
                    setPassword(result.data.data.password)
                    // setphoto(result.data.data.photo)
                    // setfile(result.data.data.photo_path)

                } else {
                    return;
                }

            })
        }
    }

    function handleChange(event) {
        setfile(...file ,...event.target.files)
      }

    function updatebackenddat() {
        console.log("photo", file);
        // const fD = new FormData();
        // fD.append('name', Fristname);
        // fD.append('gmail', email);
        // fD.append('password', password);
        // fD.append('photo', file);
        // let user_id = localStorage.getItem('_id');

        // if (user_id === undefined || user_id === null) {
        //     axios.post(`http://localhost:9600/api`, fD).then((res) => {
        //         console.log("updare", res)
        //     })
        // } else {
        // }
        // history.push('/table')

    }
    // function updatebackenddat() {
    //     const fD = new FormData();
    //     fD.append('name', Fristname);
    //     fD.append('gmail', email);
    //     fD.append('password', password);
    //     console.log(fD)
    //     axios.post(`http://localhost:8600/user/${id}`, fD).then((res) => {
    //         console.log("updare", res)
    //     })
    //     history.push('/table')
    // }


    return (

        <>

            <p class="oo" ><span>Information Form</span></p>

            <div>
                <img src={file} width="100" height="100" />
            </div>
            <form class="MM" onSubmit={submitForm}>
                <div class="bb">
                    <label htmlfor='Fristname'>Enter Your FullName:</label>
                    <input required type='text' name='Fristname' value={Fristname} onChange={(e) => setFristname(e.target.value)}></input>
                    <br />
                    {Object.keys(FirstnameErr).map((key) => {
                        return <div style={{ color: 'red' }}>{FirstnameErr[key]}</div>
                    })}
                </div>
                <br />
                <div class='A'>
                    <lable htmlFor='email'> Email:  </lable>
                    <input required type='text' name='email' autoComplete='off'
                        value={email} onChange={(e) => setEmail(e.target.value)} />
                    <br />
                    {Object.keys(emailErr).map((key) => {
                        return <div style={{ color: 'red' }}>{emailErr[key]}</div>
                    })}
                </div>
                <br />
                <div class='B'>
                    <label htmlFor="Password" name=" password">Password :</label>

                    <input type='text' name='password' value={password} onChange={(e) => setPassword(e.target.value)} />

                </div>
                <br />
                <input type='file'  ref={fileInputRef} name='file' value={file} onChange={handleChange} />
                <br />
                <br />

                <button style={{ background: 'gold' }} type='submit' onClick={updatebackenddat}>Submit</button>

            </form>
            <br />

        </>
    )


}


export default Pp;