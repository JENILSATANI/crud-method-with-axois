import logo from './logo.svg';
import './App.css';
import Upload from './Upload';
import Copy from './Copy';
import Pp from './Pp'
import { BrowserRouter as Router, Route, Switch, Redirect, } from 'react-router-dom';

function App() {
  return (
    <div className="App">
      {/* <Upload/> */}
      {/* <Copy /> */}
      {/* <Pp/> */}
      <Router>
        <Switch>
        <Route exact path='/table' component={Copy} />
        <Route path='/form' component={Pp}
          // render={props => <ItemEditForm {...props} updateItem={this.updateItem} />}

          
        />
        {/* <Route path='/upload' component={Upload}/> */}
        </Switch> 
      </Router>
    </div>
  );
}

export default App;
